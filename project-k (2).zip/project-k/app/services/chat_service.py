# file: car_chatbot.py

import os
from typing import Dict, List

from langchain_chroma import Chroma
from langchain_google_genai import ChatGoogleGenerativeAI, GoogleGenerativeAIEmbeddings
from langchain.chains import ConversationalRetrievalChain
from langchain.memory import ConversationBufferMemory
from langchain_community.chat_message_histories import ChatMessageHistory


# -------------------------
# API Key Setup (⚠️ demo only, use env variables in prod)
# -------------------------
GOOGLE_API_KEY = "AIzaSyDIsNVu-W0rtmWkdfSDE0cQRW4SOIXa2CQ"
os.environ["GOOGLE_API_KEY"] = GOOGLE_API_KEY

# -------------------------
# In-Memory Stores
# -------------------------
USER_MEMORY: Dict[str, ConversationBufferMemory] = {}
CHAT_LOGS: Dict[str, List[dict]] = {}

# -------------------------
# 1. Chat Endpoint
# -------------------------
async def chat_endpoint(query: str, user_id: str) -> str:
    try:
        retriever = get_retriever()
        chain_builder = build_chat_chain(retriever)
        answer = await generate_answer(chain_builder, user_id, query)
        log_query_response(user_id, query, answer)
        return answer
    except Exception as e:
        return error_handler(e)


# -------------------------
# 2. Get Retriever (ChromaDB)
# -------------------------
def get_retriever():
    embeddings = GoogleGenerativeAIEmbeddings(model="models/embedding-001")
    vectorstore = Chroma(persist_directory="./car_chroma", embedding_function=embeddings)
    return vectorstore.as_retriever(search_kwargs={"k": 3})


# -------------------------
# 3. Initialize Chat Model
# -------------------------
def get_chat_model():
    return ChatGoogleGenerativeAI(
        model="gemini-1.5-flash",
        temperature=0.2,
    )


# -------------------------
# 4. Build Chat Chain
# -------------------------
def build_chat_chain(retriever):
    def get_memory(user_id: str):
        if user_id not in USER_MEMORY:
            USER_MEMORY[user_id] = ConversationBufferMemory(
                memory_key="chat_history",
                chat_memory=ChatMessageHistory(),
                return_messages=True
            )
        return USER_MEMORY[user_id]

    llm = get_chat_model()
    return lambda user_id: ConversationalRetrievalChain.from_llm(
        llm=llm,
        retriever=retriever,
        memory=get_memory(user_id)
    )


# -------------------------
# 5. Generate Answer
# -------------------------
async def generate_answer(chain_builder, user_id: str, query: str) -> str:
    chain = chain_builder(user_id)
    # ✅ run in async-safe way
    result = await chain.ainvoke({"question": query})
    return result["answer"]


# -------------------------
# 6. Reset Memory
# -------------------------
def reset_memory(user_id: str):
    if user_id in USER_MEMORY:
        del USER_MEMORY[user_id]


# -------------------------
# 7. Reset Chat Endpoint
# -------------------------
async def reset_chat_endpoint(user_id: str):
    reset_memory(user_id)
    CHAT_LOGS[user_id] = []


# -------------------------
# 8. Get Conversation History
# -------------------------
async def get_history_endpoint(user_id: str):
    return CHAT_LOGS.get(user_id, [])


# -------------------------
# 9. Log Query & Response
# -------------------------
def log_query_response(user_id: str, query: str, answer: str):
    if user_id not in CHAT_LOGS:
        CHAT_LOGS[user_id] = []
    CHAT_LOGS[user_id].append({"query": query, "answer": answer})


# -------------------------
# 10. Error Handler
# -------------------------
def error_handler(exception: Exception) -> str:
    return f"Sorry, something went wrong: {str(exception)}"


# -------------------------
# Example Run
# -------------------------
if __name__ == "__main__":
    import asyncio

    async def run_demo():
        user = "user_101"

        print(await chat_endpoint("What is the mileage of Tesla Model S?", user))
        print(await chat_endpoint("Does it include insurance?", user))
        await reset_chat_endpoint(user)
        print(await get_history_endpoint(user))

    asyncio.run(run_demo())
