from fastapi import APIRouter
from pydantic import BaseModel
from app.services.chat_service import (
    chat_endpoint,
    reset_chat_endpoint,
    get_history_endpoint,
)

router = APIRouter()   # ✅ correct

# -----------------------
# Request Models
# -----------------------
class ChatRequest(BaseModel):
    user_id: str
    query: str

class ResetRequest(BaseModel):
    user_id: str


# -----------------------
# Routes
# -----------------------
@router.post("/chat/")
async def chat(request: ChatRequest):
    response = await chat_endpoint(request.query, request.user_id)
    return {"user_id": request.user_id, "response": response}


@router.post("/chat/reset/")
async def reset(request: ResetRequest):
    await reset_chat_endpoint(request.user_id)   # make it async in service
    return {"message": f"Chat reset for {request.user_id}"}


@router.get("/chat/history/{user_id}")
async def history(user_id: str):
    history_data = await get_history_endpoint(user_id)  # async service
    return {"user_id": user_id, "history": history_data}
