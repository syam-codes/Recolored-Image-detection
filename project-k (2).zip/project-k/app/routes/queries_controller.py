from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from .. import schemas, crud, database

router = APIRouter(prefix="/api/users/{user_id}/queries", tags=["queries"])

@router.post("/", response_model=schemas.QueryResponse)
def add_query(user_id: int, query: schemas.QueryCreate, db: Session = Depends(database.get_db)):
    # check if user exists
    user = crud.get_user(db, user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    created_query = crud.create_query_for_user(db, user_id, query)
    return created_query

@router.get("/", response_model=List[schemas.QueryResponse])
def list_queries(user_id: int, db: Session = Depends(database.get_db)):
    user = crud.get_user(db, user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return crud.get_queries_for_user(db, user_id)
