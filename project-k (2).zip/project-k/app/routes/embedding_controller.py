from fastapi import APIRouter
from typing import Dict
from app.services.embedding_service import (
    process_json_to_vectors,
    json_to_documents,
    load_json,
    save_to_chroma,
    clear_chroma_db
)

router = APIRouter()

# ---------------------------
# Upload JSON + Embed + Save
# ---------------------------
@router.post("/embed-json/")
async def embed_json(chunk_size: int = 500, chunk_overlap: int = 50):
    vectors = process_json_to_vectors(chunk_size, chunk_overlap)
    docs = json_to_documents()
    save_to_chroma()
    return {"message": "Embeddings created and stored in ChromaDB", "vector_count": len(vectors)}

# ---------------------------
# Clear Chroma DB
# ---------------------------
@router.delete("/clear-db/")
def clear_db():
    return clear_chroma_db()


# ---------------------------
# Debug: Print embeddings
# ---------------------------
@router.get("/print-embeddings/")
def print_embeddings_api(chunk_size: int = 500, chunk_overlap: int = 50):
    from app.services.embedding_service import print_embeddings
    vectors = print_embeddings(chunk_size, chunk_overlap)
    return {"message": "Embeddings printed in console", "vector_count": len(vectors)}
