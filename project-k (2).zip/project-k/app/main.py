from fastapi import FastAPI
from app.routes import embedding_controller,chat_controller,user_controller;
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()

# Include router

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],      # allow all origins
    allow_credentials=True,
    allow_methods=["*"],      # allow all HTTP methods
    allow_headers=["*"],      # allow all headers
)

app.include_router(embedding_controller.router)
app.include_router(chat_controller.router)
app.include_router(user_controller.router)

