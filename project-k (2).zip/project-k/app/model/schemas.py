from pydantic import BaseModel, EmailStr
from typing import List, Optional
from datetime import date

# ---- Lease schemas ----
class LeaseBase(BaseModel):
    monthly_price: Optional[float] = None
    currency: Optional[str] = None
    lease_term: Optional[int] = None
    down_payment: Optional[float] = None
    security_deposit: Optional[float] = None
    service_history: Optional[str] = None
    insurance_included: Optional[str] = None
    flexi_lease: Optional[bool] = False
    renewal_cycle: Optional[str] = None
    start_date: Optional[date] = None
    end_date: Optional[date] = None

class LeaseCreate(LeaseBase):
    vehicle_id: int

class LeaseResponse(LeaseBase):
    id: int
    vehicle_id: int
    user_id: int

    class Config:
        from_attributes = True


# ---- Car schemas ----
class CarBase(BaseModel):
    manufacturer: Optional[str] = None
    model: Optional[str] = None
    year: Optional[int] = None
    vehicle_type: Optional[str] = None
    fuel_type: Optional[str] = None
    transmission: Optional[str] = None
    color: Optional[str] = None
    top_speed: Optional[float] = None
    mileage: Optional[float] = None
    odometer: Optional[float] = None
    seating_capacity: Optional[int] = None
    cargo_capacity: Optional[float] = None
    safety_features: Optional[str] = None
    comfort_features: Optional[str] = None
    condition: Optional[str] = None
    registration_year: Optional[int] = None
    vin: Optional[str] = None
    insurance_included: Optional[str] = None

class CarCreate(CarBase):
    pass

class CarResponse(CarBase):
    id: int
    lease: Optional[LeaseResponse] = None

    class Config:
        from_attributes = True


# ---- User schemas ----
class UserBase(BaseModel):
    name: str
    email: EmailStr

class UserCreate(UserBase):
    password: str
    existing_user: Optional[bool] = False
    licence_id: Optional[str] = None

class UserLogin(BaseModel):
    email: EmailStr
    password: str

class UserResponse(UserBase):
    id: int
    existing_user: Optional[bool] = False
    licence_id: Optional[str] = None
    contract_status: Optional[str] = None
    start_date: Optional[date] = None
    end_date: Optional[date] = None
    payment_status: Optional[str] = None
    maintenance: Optional[bool] = None
    renewal_options: Optional[bool] = None
    leases: List[LeaseResponse] = []

    class Config:
        from_attributes = True


# ---- Query (chat) schemas ----
class QueryCreate(BaseModel):
    question: str
    answer: Optional[str] = None

class QueryResponse(QueryCreate):
    id: int
    user_id: int

    class Config:
        from_attributes = True
