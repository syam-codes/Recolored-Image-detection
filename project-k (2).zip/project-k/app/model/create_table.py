from app.model.database import Base, engine
from app.model.models import User, Query, Car, Lease

print("✅ Creating all tables in MySQL...")

Base.metadata.create_all(bind=engine)

print("🎉 Tables created successfully!")
