from sqlalchemy.orm import Session
from . import models, schemas
from passlib.context import CryptContext

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# password helpers
def hash_password(password: str) -> str:
    return pwd_context.hash(password)

def verify_password(plain: str, hashed: str) -> bool:
    return pwd_context.verify(plain, hashed)

# user crud
def get_user_by_email(db: Session, email: str):
    return db.query(models.User).filter(models.User.email == email).first()

def get_user(db: Session, user_id: int):
    return db.query(models.User).filter(models.User.id == user_id).first()

def create_user(db: Session, user: schemas.UserCreate):
    hashed = hash_password(user.password)
    db_user = models.User(
        name=user.name,
        email=user.email,
        password=hashed,
        existing_user=user.existing_user,
        licence_id=user.licence_id
    )
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user

# car crud
def create_car(db: Session, car: schemas.CarCreate):
    db_car = models.Car(**car.dict())
    db.add(db_car)
    db.commit()
    db.refresh(db_car)
    return db_car

def get_car(db: Session, car_id: int):
    return db.query(models.Car).filter(models.Car.id == car_id).first()

def list_cars(db: Session, skip: int = 0, limit: int = 100):
    return db.query(models.Car).offset(skip).limit(limit).all()

# lease crud
def create_lease_for_user(db: Session, user_id: int, lease: schemas.LeaseCreate):
    # ensure car exists
    car = db.query(models.Car).filter(models.Car.id == lease.vehicle_id).first()
    if not car:
        return None
    db_lease = models.Lease(
        vehicle_id=lease.vehicle_id,
        user_id=user_id,
        monthly_price=lease.monthly_price,
        currency=lease.currency,
        lease_term=lease.lease_term,
        down_payment=lease.down_payment,
        security_deposit=lease.security_deposit,
        service_history=lease.service_history,
        insurance_included=lease.insurance_included,
        flexi_lease=lease.flexi_lease,
        renewal_cycle=lease.renewal_cycle,
        start_date=lease.start_date,
        end_date=lease.end_date
    )
    db.add(db_lease)
    db.commit()
    db.refresh(db_lease)
    return db_lease

def get_leases_for_user(db: Session, user_id: int):
    return db.query(models.Lease).filter(models.Lease.user_id == user_id).all()


# Add a new query for a user
def create_query_for_user(db: Session, user_id: int, query: schemas.QueryCreate):
    db_query = models.Query(
        question=query.question,
        answer=query.answer,
        user_id=user_id
    )
    db.add(db_query)
    db.commit()
    db.refresh(db_query)
    return db_query

# Get all queries for a user
def get_queries_for_user(db: Session, user_id: int):
    return db.query(models.Query).filter(models.Query.user_id == user_id).all()
