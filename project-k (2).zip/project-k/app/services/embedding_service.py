# file: embedding_service.py
import os
import json
import shutil
import logging
from typing import List, Dict, Any
from langchain_community.vectorstores import Chroma
from langchain_google_genai import GoogleGenerativeAIEmbeddings
from langchain.text_splitter import CharacterTextSplitter
from langchain.schema import Document
import asyncio

# ---------------------------
# Logging Config
# ---------------------------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s"
)
logger = logging.getLogger(__name__)

# ---------------------------
# Global config
# ---------------------------
DEFAULT_JSON_PATH = r"C:\Users\syam\Downloads\cars_lease_data.json"
DEFAULT_PERSIST_DIR = "car_chroma"

# 🔑 Hardcoded Google API Key (⚠️ not recommended for production)
HARDCODED_API_KEY = "AIzaSyBOXulGf6ZAEj3NXPu1jkv9fRc19I3Wqtg"


# ---------------------------
# 1️⃣ Helper: get embeddings instance
# ---------------------------


def _get_embeddings(model_name: str = "models/embedding-001") -> GoogleGenerativeAIEmbeddings:
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        asyncio.set_event_loop(asyncio.new_event_loop())

    return GoogleGenerativeAIEmbeddings(model=model_name, google_api_key=HARDCODED_API_KEY)



# ---------------------------
# 2️⃣ Load JSON data
# ---------------------------
def load_json() -> List[Dict[str, Any]]:
    logger.info(f"Loading JSON data from: {DEFAULT_JSON_PATH}")
    if not os.path.exists(DEFAULT_JSON_PATH):
        logger.error(f"JSON file not found at {DEFAULT_JSON_PATH}")
        raise FileNotFoundError(f"❌ JSON file not found at {DEFAULT_JSON_PATH}")
    with open(DEFAULT_JSON_PATH, "r", encoding="utf-8") as f:
        data = json.load(f)
    if isinstance(data, dict):
        data = [data]
    logger.info(f"Loaded {len(data)} JSON records")
    return data


# ---------------------------
# 3️⃣ Convert JSON to Documents
# ---------------------------
def json_to_documents() -> List[Document]:
    json_data = load_json()
    docs = []
    for rec in json_data:
        content = " | ".join([f"{k}: {v}" for k, v in rec.items()])
        docs.append(Document(page_content=content, metadata=rec))
    logger.info(f"Converted {len(docs)} records into LangChain Documents")
    return docs


# ---------------------------
# 4️⃣ Split documents
# ---------------------------
def split_documents(docs: List[Document], chunk_size: int = 500, chunk_overlap: int = 50) -> List[Document]:
    logger.info(f"Splitting {len(docs)} documents into chunks (size={chunk_size}, overlap={chunk_overlap})")
    splitter = CharacterTextSplitter(chunk_size=chunk_size, chunk_overlap=chunk_overlap)
    split_docs = splitter.split_documents(docs)
    logger.info(f"Generated {len(split_docs)} chunks")
    return split_docs


# ---------------------------
# 5️⃣ Generate embeddings
# ---------------------------
def create_embeddings(docs: List[Document], model_name: str = "models/embedding-001") -> List[Dict[str, Any]]:
    logger.info(f"Creating embeddings for {len(docs)} documents")
    embeddings = _get_embeddings(model_name)
    vector_list = []
    for idx, doc in enumerate(docs, start=1):
        vector = embeddings.embed_query(doc.page_content)
        vector_list.append({
            "content": doc.page_content,
            "metadata": doc.metadata,
            "vector_length": len(vector),
            "vector": vector
        })
        if idx % 10 == 0 or idx == len(docs):
            logger.info(f"Embedded {idx}/{len(docs)} documents")
    return vector_list


# ---------------------------
# 6️⃣ Save to Chroma DB
# ---------------------------
def save_to_chroma(persist_dir: str = DEFAULT_PERSIST_DIR) -> Chroma:
    logger.info(f"Saving embeddings into ChromaDB at {persist_dir}")
    docs = json_to_documents()
    embeddings = _get_embeddings()
    vectordb = Chroma.from_documents(docs, embeddings, persist_directory=persist_dir)
    logger.info("Chroma DB saved successfully")
    return vectordb


# ---------------------------
# 7️⃣ Clear Chroma DB
# ---------------------------
def clear_chroma_db(persist_dir: str = DEFAULT_PERSIST_DIR) -> Dict[str, str]:
    if os.path.exists(persist_dir):
        shutil.rmtree(persist_dir)
        logger.warning(f"Chroma DB cleared at {persist_dir}")
        return {"message": "Chroma DB cleared successfully"}
    logger.info("No Chroma DB found to clear")
    return {"message": "No Chroma DB found to clear"}


# ---------------------------
# 8️⃣ Full pipeline
# ---------------------------
def process_json_to_vectors(chunk_size: int = 500, chunk_overlap: int = 50, persist: bool = False) -> List[Dict[str, Any]]:
    logger.info("🚀 Starting full pipeline: JSON → Documents → Embeddings")
    docs = json_to_documents()
    split_docs = split_documents(docs, chunk_size, chunk_overlap)
    vectors = create_embeddings(split_docs)

    if persist:
        save_to_chroma()
        logger.info("✅ Embeddings also persisted to Chroma DB")

    logger.info(f"Pipeline completed. Total vectors: {len(vectors)}")
    return vectors


# ---------------------------
# 9️⃣ Print Embeddings (for debugging)
# ---------------------------
def print_embeddings(chunk_size: int = 500, chunk_overlap: int = 50) -> List[Dict[str, Any]]:
    print("🚀 Starting embedding generation...")
    docs = json_to_documents()
    print(f"📄 Loaded {len(docs)} documents from JSON")

    split_docs = split_documents(docs, chunk_size, chunk_overlap)
    print(f"✂️ After splitting: {len(split_docs)} chunks created")

    vectors = create_embeddings(split_docs)
    print(f"🔢 Generated {len(vectors)} embeddings")

    # Print sample for debugging
    for idx, v in enumerate(vectors[:3]):  # limit to 3 for readability
        print(f"\n--- Embedding {idx+1} ---")
        print(f"Content: {v['content'][:200]}...")  # print partial content
        print(f"Vector Length: {v['vector_length']}")
        print(f"Vector Sample: {v['vector'][:10]}")  # show first 10 numbers

    return vectors
