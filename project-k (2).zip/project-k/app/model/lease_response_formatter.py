# file: app/utils/lease_response_formatter.py

import json
from langchain_google_genai import ChatGoogleGenerativeAI

# Initialize LLM
llm = ChatGoogleGenerativeAI(model="gemini-pro", temperature=0.7)

def format_lease_response(query: str, vehicle_docs: list) -> str:
    """
    Use Gemini LLM to generate natural, conversational responses
    instead of rule-based templating.
    """
    if not vehicle_docs:
        return "I couldn’t find any matching vehicles for your query."

    # Convert docs to JSON string
    vehicles_json = json.dumps(vehicle_docs, indent=2)

    # Create prompt for the LLM
    prompt = f"""
You are a helpful assistant for a vehicle leasing chatbot. 
The user asked: "{query}".

Here are the matching vehicle records:
{vehicles_json}

Based only on this data, generate a clear and natural answer. 
Do NOT add extra vehicles or assumptions.
"""
    response = llm.invoke(prompt)
    return response.content
