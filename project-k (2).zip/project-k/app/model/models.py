from sqlalchemy import (
    Column, Integer, String, Boolean, Date, Float, ForeignKey, Text
)
from sqlalchemy.orm import relationship
from .database import Base

class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False)
    email = Column(String(100), unique=True, index=True)
    password = Column(String(255), nullable=False)

    # optional user attributes
    existing_user = Column(Boolean, default=False)
    licence_id = Column(String(50), nullable=True)
    contract_status = Column(String(50), default="Active")
    start_date = Column(Date, nullable=True)
    end_date = Column(Date, nullable=True)
    payment_status = Column(String(50), default="Up-to-date")
    maintenance = Column(Boolean, default=True)
    renewal_options = Column(Boolean, default=True)

    queries = relationship("Query", back_populates="user", cascade="all, delete-orphan")
    leases = relationship("Lease", back_populates="user", cascade="all, delete-orphan")


class Query(Base):
    __tablename__ = "queries"

    id = Column(Integer, primary_key=True, index=True)
    question = Column(Text)
    answer = Column(Text)
    user_id = Column(Integer, ForeignKey("users.id"))

    user = relationship("User", back_populates="queries")


class Car(Base):
    __tablename__ = "cars"

    id = Column(Integer, primary_key=True, index=True)  # VehicleID
    manufacturer = Column(String(100))
    model = Column(String(100))
    year = Column(Integer)
    vehicle_type = Column(String(50))
    fuel_type = Column(String(50))
    transmission = Column(String(50))
    color = Column(String(50))
    top_speed = Column(Float, nullable=True)
    mileage = Column(Float, nullable=True)
    odometer = Column(Float, nullable=True)
    seating_capacity = Column(Integer, nullable=True)
    cargo_capacity = Column(Float, nullable=True)
    safety_features = Column(Text, nullable=True)
    comfort_features = Column(Text, nullable=True)
    condition = Column(String(50), nullable=True)
    registration_year = Column(Integer, nullable=True)
    vin = Column(String(100), unique=True, nullable=True)
    insurance_included = Column(String(255), nullable=True)

    lease = relationship("Lease", back_populates="car", uselist=False, cascade="all, delete-orphan")


class Lease(Base):
    __tablename__ = "leases"

    id = Column(Integer, primary_key=True, index=True)
    vehicle_id = Column(Integer, ForeignKey("cars.id"))
    user_id = Column(Integer, ForeignKey("users.id"))

    monthly_price = Column(Float, nullable=True)
    currency = Column(String(10), nullable=True)
    lease_term = Column(Integer, nullable=True)  # months
    down_payment = Column(Float, nullable=True)
    security_deposit = Column(Float, nullable=True)
    service_history = Column(Text, nullable=True)
    insurance_included = Column(String(255), nullable=True)
    flexi_lease = Column(Boolean, default=False)
    renewal_cycle = Column(String(100), nullable=True)
    start_date = Column(Date, nullable=True)
    end_date = Column(Date, nullable=True)

    car = relationship("Car", back_populates="lease")
    user = relationship("User", back_populates="leases")
