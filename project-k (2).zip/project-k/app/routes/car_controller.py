from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from .. import schemas, crud, database

router = APIRouter(prefix="/api/cars", tags=["cars"])

@router.post("/", response_model=schemas.CarResponse)
def add_car(car: schemas.CarCreate, db: Session = Depends(database.get_db)):
    created = crud.create_car(db, car)
    return created

@router.get("/", response_model=List[schemas.CarResponse])
def list_cars(skip: int = 0, limit: int = 50, db: Session = Depends(database.get_db)):
    return crud.list_cars(db, skip=skip, limit=limit)

@router.get("/{car_id}", response_model=schemas.CarResponse)
def get_car(car_id: int, db: Session = Depends(database.get_db)):
    car = crud.get_car(db, car_id)
    if not car:
        raise HTTPException(status_code=404, detail="Car not found")
    return car
