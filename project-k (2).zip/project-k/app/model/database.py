from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base

# ✅ Use your new MySQL user and database
DATABASE_URL = "mysql+pymysql://root:root@localhost:3306/fastapi_db"

# Create the SQLAlchemy engine
engine = create_engine(DATABASE_URL, echo=True)  # echo=True shows SQL logs

# Create a configured "Session" class
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Base class for your models
Base = declarative_base()

# Dependency to get DB session in routes
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()