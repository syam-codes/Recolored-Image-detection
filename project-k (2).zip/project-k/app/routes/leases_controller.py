from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from .. import schemas, crud, database

router = APIRouter(prefix="/api", tags=["leases"])

@router.post("/users/{user_id}/lease", response_model=schemas.LeaseResponse)
def add_lease(user_id: int, lease: schemas.LeaseCreate, db: Session = Depends(database.get_db)):
    # ensure user exists
    user = crud.get_user(db, user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    created = crud.create_lease_for_user(db, user_id, lease)
    if not created:
        raise HTTPException(status_code=404, detail="Car (vehicle) not found")
    return created

@router.get("/users/{user_id}/lease", response_model=List[schemas.LeaseResponse])
def get_user_leases(user_id: int, db: Session = Depends(database.get_db)):
    user = crud.get_user(db, user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return crud.get_leases_for_user(db, user_id)
