import os
from dotenv import load_dotenv

load_dotenv()

GEMINI_API_KEY = "AIzaSyBOXulGf6ZAEj3NXPu1jkv9fRc19I3Wqtg"
VECTOR_DB_PATH = os.getenv("VECTOR_DB_PATH", "./chroma_db")
REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379")
JSON_DATA_PATH = os.getenv("JSON_DATA_PATH", "C:\\Users\\syam\\Downloads\\cars.json")
